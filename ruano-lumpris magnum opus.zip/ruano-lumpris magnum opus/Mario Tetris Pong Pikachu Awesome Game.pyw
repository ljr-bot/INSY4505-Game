﻿"""Mario Tetris Pong Pikachu Game, a one-player paddle game for Python 3 and Tkinter."""

import os
import random
import subprocess
import tkinter as tk
import winsound
from pathlib import Path
from time import monotonic


TITLE = "Mario Tetris Pong Pikachu Game"
WIDTH, HEIGHT = 760, 460
PADDLE_WIDTH, PADDLE_HEIGHT = 12, 84
CPU_SPEED = 4.5
BALL_RADIUS = 13
WIN_SCORE = 7
DRAW_TRIPS = 8
DRAW_BLOCK_BOUNCES = 10
CPU_X = WIDTH - 28 - PADDLE_WIDTH
CAR_IMPACT_SECONDS = 0.48
CAR_EXIT_SECONDS = 0.70
BONUS_FRAME_SIZE = 116
BONUS_FRAME_COLUMNS = 12
BONUS_FRAME_COUNT = 120
BONUS_ROTATION_SECONDS = 10
BONUS_RESPAWN_SECONDS = 12
CPU_DISABLED_SECONDS = 1.5
DRAW_DURATION_MS = 2500
ARENA_TOP, ARENA_BOTTOM = 66, HEIGHT - 40
BLOCK_SIZE = 24
BLOCK_COLUMNS, BLOCK_ROWS = 20, 14
BLOCK_LEFT = (WIDTH - BLOCK_COLUMNS * BLOCK_SIZE) // 2
BLOCK_TOP = ARENA_BOTTOM - BLOCK_ROWS * BLOCK_SIZE
BLOCK_INTERVAL = 140  # Active frames, about 2.2 seconds.
BLOCK_FALL = 4  # Pixels per frame. Divides BLOCK_SIZE evenly.
TETROMINOES = (
    ("#66d9ef", ((0, 0), (1, 0), (2, 0), (3, 0))),
    ("#f6d365", ((0, 0), (1, 0), (0, 1), (1, 1))),
    ("#bc93fa", ((0, 0), (1, 0), (2, 0), (1, 1))),
    ("#ffa782", ((0, 0), (0, 1), (1, 1), (2, 1))),
    ("#8fa8ff", ((2, 0), (0, 1), (1, 1), (2, 1))),
    ("#75f4ce", ((1, 0), (2, 0), (0, 1), (1, 1))),
    ("#ff829c", ((0, 0), (1, 0), (1, 1), (2, 1))),
)
ASSETS = Path(__file__).resolve().with_name("Neon Rally Assets")
BACKGROUND_TRACK = Path(r"C:\Users\lukas\Downloads\01. Ground Theme.mp3")


class NeonRally:
    def __init__(self, root):
        self.root = root
        self.root.title(TITLE)
        self.root.resizable(False, False)
        self.canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT,
                                bg="#101b2d", highlightthickness=0)
        self.canvas.pack()
        self.background = tk.PhotoImage(file=ASSETS / "court-background.png")
        self.mario_hat = tk.PhotoImage(file=ASSETS / "mario.png")
        self.bowser_hat = tk.PhotoImage(file=ASSETS / "bowser.png")
        self.mushroom = tk.PhotoImage(file=ASSETS / "mushroom.png")
        self.draw_sonic = tk.PhotoImage(file=ASSETS / "draw-sonic.png")
        self.draw_banner = tk.PhotoImage(file=ASSETS / "draw-banner.png")
        self.showing_draw = False
        self.bonus_glow = tk.PhotoImage(file=ASSETS / "bonus-glow.png")
        self.bonus_frames = self.load_bonus_frames()
        self.bonus_car = tk.PhotoImage(file=ASSETS / "bonus-car.png")
        self.bonus_splatter = tk.PhotoImage(file=ASSETS / "bonus-splatter.png")
        self.canvas.bind("<Button-1>", self.launch_car)
        self.keys = set()
        root.bind("<KeyPress>", self.key_down)
        root.bind("<KeyRelease>", self.key_up)
        root.bind("<FocusOut>", lambda event: self.keys.clear())
        self.player_wins = 0
        self.reset()
        self.tick()

    def load_bonus_frames(self):
        atlas = tk.PhotoImage(file=ASSETS / "bonus-rotation.png")
        frames = []
        size = BONUS_FRAME_SIZE
        for index in range(BONUS_FRAME_COUNT):
            row, column = divmod(index, BONUS_FRAME_COLUMNS)
            x, y = column * size, row * size
            frame = tk.PhotoImage(width=size, height=size)
            self.root.tk.call(frame, "copy", atlas, "-from", x, y, x + size, y + size)
            frames.append(frame)
        return frames

    def reset(self):
        self.reset_car_bonus()
        self.showing_draw = False
        self.player_score = self.cpu_score = 0
        self.clear_blocks()
        self.player_y = self.cpu_y = HEIGHT / 2
        self.serve("Press Space to serve")

    def reset_car_bonus(self):
        self.car_started_at = None
        self.cpu_disabled_until = 0
        self.impact_y = None
        self.move_car_bonus()

    def move_car_bonus(self):
        self.bonus_x = random.randint(145, WIDTH - 145)
        self.bonus_y = random.randint(ARENA_TOP + 78, ARENA_BOTTOM - 78)

    def launch_car(self, event):
        if self.message or self.showing_draw or self.car_started_at is not None:
            return
        bounds = self.canvas.bbox("car_bonus")
        if bounds is None:
            return
        left, top, right, bottom = bounds
        if not (left <= event.x < right and top <= event.y < bottom):
            return
        self.car_started_at = monotonic()
        self.play_sound("bonus-screech.wav")

    def update_car(self, now):
        if (self.car_started_at is not None and self.impact_y is None
                and now - self.car_started_at >= CAR_IMPACT_SECONDS):
            self.impact_y = self.cpu_y
            self.cpu_disabled_until = now + CPU_DISABLED_SECONDS
            self.draw_trips = 0
            self.cpu_hit = self.block_return = False

        if (self.impact_y is not None and now >= self.cpu_disabled_until
                and now - self.car_started_at >= BONUS_RESPAWN_SECONDS):
            self.reset_car_bonus()

    def clear_blocks(self):
        self.stacked_blocks = {}
        self.falling_blocks = []
        self.fall_offset = 0
        self.spawn_timer = BLOCK_INTERVAL

    @property
    def speed_multiplier(self):
        return 1 + 0.30 * self.player_wins / (20 + self.player_wins)

    def serve(self, message):
        if self.car_started_at is None:
            self.move_car_bonus()
        self.draw_trips = 0
        self.block_bounces = 0
        self.cpu_hit = False
        self.block_return = False
        self.x, self.y = WIDTH / 2, HEIGHT / 2
        # Serve above the stack if it has reached the center of the court.
        heights = [y for x, y, _ in self.block_positions()
                   if x - BALL_RADIUS < self.x < x + BLOCK_SIZE + BALL_RADIUS]
        if heights:
            self.y = min(self.y, min(heights) - BALL_RADIUS - 1)
        if self.y < ARENA_TOP + BALL_RADIUS:
            self.x, self.y = BLOCK_LEFT - 2 * BALL_RADIUS, HEIGHT / 2
        self.vx = random.choice((-6.1, 6.1)) * self.speed_multiplier
        self.vy = random.choice((-2.6, 2.6)) * self.speed_multiplier
        self.message = message

    def update_blocks(self):
        self.spawn_timer -= 1
        if not self.falling_blocks and self.spawn_timer <= 0:
            self.spawn_timer = BLOCK_INTERVAL
            color, shape = random.choice(TETROMINOES)
            width = max(x for x, _ in shape) + 1
            columns = list(range(BLOCK_COLUMNS - width + 1))
            random.shuffle(columns)
            for column in columns:
                cells = [(column + x, y) for x, y in shape]
                if all(cell not in self.stacked_blocks for cell in cells):
                    self.falling_blocks = cells
                    self.falling_color = color
                    break

        if not self.falling_blocks:
            return
        below = [(x, y + 1) for x, y in self.falling_blocks]
        if self.fall_offset == 0 and any(
            y >= BLOCK_ROWS or (x, y) in self.stacked_blocks for x, y in below
        ):
            self.stacked_blocks.update(dict.fromkeys(self.falling_blocks, self.falling_color))
            self.falling_blocks = []
            return
        self.fall_offset += BLOCK_FALL
        if self.fall_offset == BLOCK_SIZE:
            self.falling_blocks = below
            self.fall_offset = 0

    def block_positions(self):
        for (column, row), color in self.stacked_blocks.items():
            yield BLOCK_LEFT + column * BLOCK_SIZE, BLOCK_TOP + row * BLOCK_SIZE, color
        for column, row in self.falling_blocks:
            yield (BLOCK_LEFT + column * BLOCK_SIZE,
                   BLOCK_TOP + row * BLOCK_SIZE + self.fall_offset, self.falling_color)

    def bounce_off_blocks(self, old_x, old_y):
        radius = BALL_RADIUS
        for x, y, _ in self.block_positions():
            left, right = x - radius, x + BLOCK_SIZE + radius
            top, bottom = y - radius, y + BLOCK_SIZE + radius
            if not (left < self.x < right and top < self.y < bottom):
                continue

            # Prefer the face the mushroom crossed. If a falling block
            # overlaps it, use the nearest face with room inside the court.
            faces = [
                (left, "x", -1, old_x <= left, self.x - left),
                (right, "x", 1, old_x >= right, right - self.x),
            ]
            if top >= ARENA_TOP + radius:
                faces.append((top, "y", -1, old_y <= top, self.y - top))
            if bottom <= ARENA_BOTTOM - radius:
                faces.append((bottom, "y", 1, old_y >= bottom, bottom - self.y))
            edge, axis, direction, _, _ = min(faces, key=lambda face: (not face[3], face[4]))
            if axis == "x":
                self.x = edge
                if self.cpu_hit and self.vx < 0 and direction > 0:
                    self.block_return = True
                elif self.vx > 0 and direction < 0:
                    self.draw_trips = 0
                    self.cpu_hit = self.block_return = False
                self.vx = direction * abs(self.vx)
            else:
                self.y = edge
                self.vy = direction * max(abs(self.vy), 2.6 * self.speed_multiplier)
            return True
        return False

    def show_draw(self):
        self.showing_draw = True
        self.root.after(DRAW_DURATION_MS, self.reset)

    def key_down(self, event):
        key = event.keysym.lower()
        if key in self.keys:
            return
        self.keys.add(key)
        if self.showing_draw:
            return
        if key == "space":
            if max(self.player_score, self.cpu_score) == WIN_SCORE:
                self.reset()
            self.message = ""
        elif key == "r":
            self.reset()

    def key_up(self, event):
        self.keys.discard(event.keysym.lower())

    @staticmethod
    def clamp_paddle(y):
        half = PADDLE_HEIGHT / 2
        return max(66 + half, min(HEIGHT - 40 - half, y))

    def update(self):
        now = monotonic()
        self.update_car(now)
        cpu_disabled = now < self.cpu_disabled_until
        up = bool({"w", "up"} & self.keys)
        down = bool({"s", "down"} & self.keys)
        self.player_y = self.clamp_paddle(self.player_y + 7 * (down - up))
        target = self.y if self.vx > 0 else HEIGHT / 2
        if not cpu_disabled:
            movement = max(-CPU_SPEED, min(CPU_SPEED, target - self.cpu_y))
            self.cpu_y = self.clamp_paddle(self.cpu_y + movement)

        self.update_blocks()
        old_x, old_y = self.x, self.y
        self.x += self.vx
        self.y += self.vy
        top, bottom = ARENA_TOP + BALL_RADIUS, ARENA_BOTTOM - BALL_RADIUS
        if self.y < top or self.y > bottom:
            self.y = max(top, min(bottom, self.y))
            self.vy = -self.vy
            self.block_bounces = 0

        left = 28 + PADDLE_WIDTH + BALL_RADIUS
        right = CPU_X - BALL_RADIUS
        reach = PADDLE_HEIGHT / 2 + BALL_RADIUS
        if self.vx < 0 and self.x <= left <= old_x and abs(self.y - self.player_y) <= reach:
            self.bounce(left, self.player_y, 1, "mario-hit.wav")
            self.draw_trips = 0
            self.cpu_hit = self.block_return = False
        elif (not cpu_disabled and self.vx > 0 and old_x <= right <= self.x
              and abs(self.y - self.cpu_y) <= reach):
            self.bounce(right, self.cpu_y, -1, "bowser-hit.wav")
            self.draw_trips = self.draw_trips + 1 if self.block_return else 0
            self.cpu_hit = True
            self.block_return = False
            if self.draw_trips == DRAW_TRIPS:
                self.show_draw()
                return

        if self.bounce_off_blocks(old_x, old_y):
            self.block_bounces += 1
            if self.block_bounces == DRAW_BLOCK_BOUNCES:
                self.show_draw()
                return

        if self.x < -BALL_RADIUS or self.x > WIDTH + BALL_RADIUS:
            if self.x < 0:
                self.cpu_score += 1
            else:
                self.player_score += 1
            if self.player_score == WIN_SCORE:
                self.player_wins += 1
                self.serve("You win!   Space to play again")
            elif self.cpu_score == WIN_SCORE:
                self.clear_blocks()
                self.serve("Computer wins   Space to play again")
            else:
                self.serve("Press Space to serve")

    def bounce(self, x, paddle_y, direction, sound):
        self.block_bounces = 0
        self.x = x
        speed = self.speed_multiplier
        self.vx = direction * min(13 * speed, abs(self.vx) + 0.65 * speed)
        offset = (self.y - paddle_y) / (PADDLE_HEIGHT / 2 + BALL_RADIUS)
        self.vy = 7 * speed * offset
        if self.car_started_at is None or monotonic() - self.car_started_at >= CAR_EXIT_SECONDS:
            self.play_sound(sound)

    @staticmethod
    def play_sound(sound):
        try:
            winsound.PlaySound(str(ASSETS / sound),
                               winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_NODEFAULT)
        except RuntimeError:
            # Keep the game playable if audio is unavailable.
            pass

    def draw(self):
        canvas = self.canvas
        canvas.delete("all")
        canvas.create_image(0, 0, image=self.background, anchor="nw")
        if self.showing_draw:
            canvas.create_image(164, HEIGHT / 2, image=self.draw_sonic)
            canvas.create_image(462, HEIGHT / 2, image=self.draw_banner)
            return
        canvas.create_line(0, 66, WIDTH, 66, fill="#354762")
        canvas.create_line(0, HEIGHT - 40, WIDTH, HEIGHT - 40, fill="#354762")
        canvas.create_line(WIDTH / 2, 66, WIDTH / 2, HEIGHT - 40,
                           fill="#354762", dash=(4, 8))
        canvas.create_text(28, 33, text=f"YOU   {self.player_score}", anchor="w",
                           fill="#75f4ce", font=("Segoe UI", 16, "bold"))
        canvas.create_text(WIDTH - 28, 33, text=f"{self.cpu_score}   COMPUTER",
                           anchor="e", fill="#ffa782", font=("Segoe UI", 16, "bold"))
        canvas.create_text(WIDTH / 2, 33, text=TITLE, fill="#e8efff",
                           font=("Segoe UI", 17, "bold"))
        for x, y, color in self.block_positions():
            canvas.create_rectangle(x, y, x + BLOCK_SIZE, y + BLOCK_SIZE,
                                    fill=color, outline="#101b2d", width=2)
            canvas.create_line(x + 4, y + 4, x + BLOCK_SIZE - 4, y + 4,
                               fill="#e8efff")

        now = monotonic()
        paddles = [(28, self.player_y, "#75f4ce", self.mario_hat)]
        if now < self.cpu_disabled_until:
            canvas.create_image(CPU_X, self.impact_y, image=self.bonus_splatter)
        else:
            paddles.append((CPU_X, self.cpu_y, "#ffa782", self.bowser_hat))
        for x, y, color, hat in paddles:
            canvas.create_rectangle(x, y - PADDLE_HEIGHT / 2,
                                    x + PADDLE_WIDTH, y + PADDLE_HEIGHT / 2,
                                    fill=color, width=0)
            canvas.create_image(x + PADDLE_WIDTH / 2, y - PADDLE_HEIGHT / 2,
                                image=hat, anchor="n")
        if self.message:
            canvas.create_rectangle(178, 199, WIDTH - 178, 261, fill="#192a44", width=0)
            canvas.create_text(WIDTH / 2, 230, text=self.message, fill="#ffffff",
                               font=("Segoe UI", 15, "bold"))
        else:
            if self.car_started_at is None:
                frame = int(now * BONUS_FRAME_COUNT / BONUS_ROTATION_SECONDS) % BONUS_FRAME_COUNT
                canvas.create_image(self.bonus_x, self.bonus_y, image=self.bonus_glow)
                canvas.create_image(self.bonus_x, self.bonus_y,
                                    image=self.bonus_frames[frame], tags="car_bonus")
            canvas.create_image(self.x, self.y, image=self.mushroom)
        if self.car_started_at is not None:
            elapsed = now - self.car_started_at
            if elapsed < CAR_EXIT_SECONDS:
                half_width = self.bonus_car.width() / 2
                distance = CPU_X + 10
                car_x = -half_width + distance * elapsed / CAR_IMPACT_SECONDS
                car_y = self.cpu_y if self.impact_y is None else self.impact_y
                canvas.create_image(car_x, car_y, image=self.bonus_car)
        canvas.create_text(WIDTH / 2, HEIGHT - 20,
                           text="W/S or arrows to move   |   R to reset   |   First to 7",
                           fill="#adbfdb", font=("Segoe UI", 11))

    def tick(self):
        if not self.showing_draw:
            if self.message:
                self.update_car(monotonic())
            else:
                self.update()
        self.draw()
        self.root.after(16, self.tick)


def start_background_music():
    if not BACKGROUND_TRACK.is_file():
        return None

    # WPF plays the MP3 independently of the game's winsound effects.
    player_script = r"""
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName PresentationCore
$game = [System.Diagnostics.Process]::GetProcessById([int]$env:PONG_MUSIC_GAME_PID)
$player = [System.Windows.Media.MediaPlayer]::new()
$player.Volume = 0.18
$player.add_MediaEnded({
    $player.Position = [TimeSpan]::Zero
    $player.Play()
})
$player.add_MediaFailed({
    [System.Windows.Threading.Dispatcher]::CurrentDispatcher.InvokeShutdown()
})
$timer = [System.Windows.Threading.DispatcherTimer]::new()
$timer.Interval = [TimeSpan]::FromSeconds(1)
$timer.add_Tick({
    if ($game.HasExited) {
        [System.Windows.Threading.Dispatcher]::CurrentDispatcher.InvokeShutdown()
    }
})
$timer.Start()
try {
    $player.Open([uri]$env:PONG_MUSIC_TRACK)
    $player.Play()
    [System.Windows.Threading.Dispatcher]::Run()
} finally {
    $timer.Stop()
    $player.Close()
    $game.Dispose()
}
"""
    environment = os.environ.copy()
    environment["PONG_MUSIC_TRACK"] = str(BACKGROUND_TRACK)
    environment["PONG_MUSIC_GAME_PID"] = str(os.getpid())
    powershell = Path(os.environ["SystemRoot"]) / (
        "System32/WindowsPowerShell/v1.0/powershell.exe"
    )
    try:
        return subprocess.Popen(
            [str(powershell), "-NoProfile", "-NonInteractive", "-STA",
             "-Command", player_script],
            env=environment,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=subprocess.CREATE_NO_WINDOW,
        )
    except OSError:
        return None


if __name__ == "__main__":
    window = tk.Tk()
    NeonRally(window)
    background_music = start_background_music()
    try:
        window.mainloop()
    finally:
        if background_music is not None:
            background_music.terminate()
            background_music.wait()
